﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PCalculadora
{
    public partial class Form1 : Form
    {
        double numero1, numero2, resultado;

        private void TextBox1_Validating(object sender, CancelEventArgs e)
        {
            if(!Double.TryParse(textBox1.Text,out numero1))
            {
                MessageBox.Show("Número 1 inválido!");
            }
        }

        private void TextBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void TextBox2_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(textBox2.Text, out numero1))
            {
                MessageBox.Show("Número 2 inválido!");
            }
        }

        private void BtnSoma_Click(object sender, EventArgs e)
        {
            if(Double.TryParse(textBox1.Text, out numero1) && Double.TryParse(textBox2.Text, out numero2))
            {
                resultado = numero1 + numero2;
                textBox3.Text = resultado.ToString();
            }
            else
                MessageBox.Show("Número inválido");
        }    

        private void BtnSubtrai_Click(object sender, EventArgs e)
        {
            if (Double.TryParse(textBox1.Text, out numero1) && Double.TryParse(textBox2.Text, out numero2))
            {
                resultado = numero1 - numero2;
                textBox3.Text = resultado.ToString();
            }
            else
                MessageBox.Show("Número inválido");
        }

        private void BtnMultiplica_Click(object sender, EventArgs e)
        {
            if (Double.TryParse(textBox1.Text, out numero1) && Double.TryParse(textBox2.Text, out numero2))
            {
                resultado = numero1 * numero2;
                textBox3.Text = resultado.ToString();
            }
            else
                MessageBox.Show("Número inválido");
        }

        private void BtnDivide_Click(object sender, EventArgs e)
        {
            if (Double.TryParse(textBox1.Text, out numero1) && Double.TryParse(textBox2.Text, out numero2))
            {
                resultado = numero1 / numero2;
                textBox3.Text = resultado.ToString();
            }
            else
                MessageBox.Show("Número inválido");
        }

        private void BtnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void BtnLimpar_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void LblN1_Click(object sender, EventArgs e)
        {

        }
    }
}
